function quality = quality_deviation( ...
    viscosity, minViscosity, maxViscosity)

quality = struct();

quality.current = viscosity;
quality.lowerLimit = minViscosity;
quality.upperLimit = maxViscosity;

if viscosity < minViscosity

    quality.status = "BELOW_SPECIFICATION";

elseif viscosity > maxViscosity

    quality.status = "ABOVE_SPECIFICATION";

else

    quality.status = "WITHIN_SPECIFICATION";

end

end
