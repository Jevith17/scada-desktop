function data = clean_process_data(data)

fprintf('\nCleaning process data...\n');

% Remove completely empty rows
data = rmmissing(data, 'MinNumMissing', width(data));

% Convert timestamp
if ismember("Timestamp", data.Properties.VariableNames)

    if ~isdatetime(data.Timestamp)
        data.Timestamp = datetime(data.Timestamp);
    end

end

% Sort chronologically
if ismember("Timestamp", data.Properties.VariableNames)
    data = sortrows(data, "Timestamp");
end

% Remove duplicate timestamps within same batch
if all(ismember(["Timestamp","BatchID"], ...
        data.Properties.VariableNames))

    [~, idx] = unique(data(:,["Timestamp","BatchID"]), ...
        'rows', 'stable');

    data = data(idx,:);

end

fprintf('Cleaning completed.\n');
fprintf('Remaining rows: %d\n', height(data));

end
