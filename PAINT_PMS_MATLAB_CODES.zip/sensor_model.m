function y = sensor_model(trueValue, bias, noise)

y = trueValue + bias + noise;

end
