function model = calibrate_valve(data)

model = struct();

required = ["ValvePosition","OutletFlow"];

if ~all(ismember(required, ...
        data.Properties.VariableNames))

    model.available = false;
    return;
end

valid = isfinite(data.ValvePosition) & ...
        isfinite(data.OutletFlow);

X = data.ValvePosition(valid);
Y = data.OutletFlow(valid);

model.coefficients = polyfit(X,Y,2);

end
