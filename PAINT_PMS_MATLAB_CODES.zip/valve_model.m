function flow = valve_model( ...
    valvePosition, valveCoefficient, pressureDrop)

valveOpening = valvePosition / 100;

flow = valveCoefficient .* ...
       valveOpening .* ...
       sqrt(max(pressureDrop,0));

end
