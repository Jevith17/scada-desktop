function results = validate_model(actual,predicted)

results = struct();

variables = fieldnames(actual);

for i = 1:numel(variables)

    name = variables{i};

    if isfield(predicted,name)

        results.(name) = ...
            calculate_model_error( ...
                actual.(name), ...
                predicted.(name));

    end
end

end
