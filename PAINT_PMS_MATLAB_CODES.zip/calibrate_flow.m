function model = calibrate_flow(data)

model = struct();

X = data.InletFlow;
Y = data.OutletFlow;

valid = isfinite(X) & isfinite(Y);

X = X(valid);
Y = Y(valid);

if numel(X) < 5
    error("Insufficient flow data for calibration.");
end

p = polyfit(X,Y,1);

model.slope = p(1);
model.intercept = p(2);

model.predict = @(x) ...
    model.slope*x + model.intercept;

end
