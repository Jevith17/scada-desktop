function json = generate_diagnosis_json(diagnosis)

output = struct();

output.active_fault = diagnosis.active_fault;

output.confidence = diagnosis.confidence;

output.evidence = diagnosis.evidence;

output.detected_at = ...
    char(datetime('now','Format', ...
    "yyyy-MM-dd'T'HH:mm:ss"));

json = jsonencode(output);

end
