function residuals = residual_generator(measured,predicted)

residuals = struct();

residuals.level = ...
    measured.Level - predicted.Level;

residuals.temperature = ...
    measured.Temperature - predicted.Temperature;

residuals.flow = ...
    measured.Flow - predicted.Flow;

residuals.pressure = ...
    measured.Pressure - predicted.Pressure;

residuals.rpm = ...
    measured.RPM - predicted.RPM;

residuals.viscosity = ...
    measured.Viscosity - predicted.Viscosity;

end
