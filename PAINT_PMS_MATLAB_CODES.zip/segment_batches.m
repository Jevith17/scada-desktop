function batches = segment_batches(data)

if ~ismember("BatchID", data.Properties.VariableNames)
    error("BatchID column is required.");
end

batchIDs = unique(data.BatchID);

batches = struct();

for i = 1:numel(batchIDs)

    id = batchIDs(i);

    if iscell(id)
        id = id{1};
    end

    field = matlab.lang.makeValidName(string(id));

    batches.(field) = ...
        data(strcmp(string(data.BatchID), string(id)), :);

end

fprintf("Number of batches detected: %d\n", ...
    numel(batchIDs));

end
