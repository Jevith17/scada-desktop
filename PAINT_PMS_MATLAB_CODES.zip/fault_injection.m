function
F3 Feed pump malfunction
F4 Control valve malfunction
F5 Tank leakage
F6 Viscosity/quality deviation

code:

function output = fault_injection(input, faultCode, severity)

output = input;

switch upper(faultCode)

    case "TEMP_SENSOR_DRIFT"

        output.Temperature = ...
            input.Temperature + severity;

    case "AGITATOR_MOTOR_MALFUNCTION"

        output.AgitatorRPM = ...
            input.AgitatorRPM .* (1-severity);

    case "FEED_PUMP_MALFUNCTION"

        output.InletFlow = ...
            input.InletFlow .* (1-severity);

    case "CONTROL_VALVE_MALFUNCTION"

        output.ValvePosition = ...
            input.ValvePosition .* (1-severity);

    case "TANK_LEAKAGE"

        output.LeakageFlow = severity;

    case "VISCOSITY_QUALITY_DEVIATION"

        output.Viscosity = ...
            input.Viscosity .* (1+severity);

    otherwise

        error("Unknown fault code.");

end

end
