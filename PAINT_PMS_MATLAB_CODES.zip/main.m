clear;
clc;
close all;

fprintf('\n');
fprintf('============================================\n');
fprintf(' PAINT MIXING DIGITAL TWIN\n');
fprintf(' REAL DATA + MATLAB/SIMULINK + FAULT DIAGNOSIS\n');
fprintf('============================================\n');

%% 1. Configuration

cfg = process_config();

%% 2. Load company workbook

filename = ...
    "data/raw/company_paint_data.xlsx";

raw = load_company_excel(filename);

%% 3. Map company columns

map = map_company_columns();

%% 4. Extract process data

% Adapt after actual workbook headers are inspected
processData = raw.ProcessData;

%% 5. Clean

processData = ...
    clean_process_data(processData);

%% 6. Outlier detection

variables = [
    "TankLevel"
    "InletFlow"
    "OutletFlow"
    "Temperature"
    "AgitatorRPM"
    "ValvePosition"
];

[processData,outlierFlags] = ...
    detect_outliers(processData,variables);

%% 7. Synchronize

processData = ...
    synchronize_data(processData,seconds(10));

%% 8. Segment batches

batches = segment_batches(processData);

%% 9. Calibration / validation split

[calibrationData,validationData] = ...
    split_calibration_validation(processData);

%% 10. Parameter identification

params = identify_parameters(calibrationData);

%% 11. Calibration

params.flow = ...
    calibrate_flow(calibrationData);

params.temperature = ...
    calibrate_temperature(calibrationData);

params.agitator = ...
    calibrate_agitator(calibrationData);

params.pump = ...
    calibrate_pump(calibrationData);

params.valve = ...
    calibrate_valve(calibrationData);

params.viscosity = ...
    calibrate_viscosity(calibrationData);

%% 12. Build Simulink model

build_paint_twin();

%% 13. Run Simulink

% simOut = sim("simulink/Paint_Mixing_DigitalTwin");

%% 14. Generate residuals

% residuals = residual_generator(...);

%% 15. Fault detection

% alarms = detect_faults(...);

%% 16. Fault diagnosis

% diagnosis = diagnose_fault(...);

%% 17. Validate

% validationResults = validate_model(...);

%% 18. Generate API output

% liveJSON = generate_live_json(...);
% trendJSON = generate_trend_json(...);
% alarmJSON = generate_alarm_json(...);
% diagnosisJSON = generate_diagnosis_json(...);
% batchJSON = generate_batch_json(...);

fprintf('\n============================================\n');
fprintf(' PIPELINE COMPLETED\n');
fprintf('============================================\n');
