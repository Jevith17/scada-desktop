function params = identify_parameters(data)

params = struct();

fprintf("\nIdentifying model parameters...\n");

% Flow relationship
if all(ismember(["InletFlow","OutletFlow"], ...
        data.Properties.VariableNames))

    params.flow.inletMean = ...
        mean(data.InletFlow,'omitnan');

    params.flow.outletMean = ...
        mean(data.OutletFlow,'omitnan');

end

% Temperature
if ismember("Temperature",data.Properties.VariableNames)

    params.temperature.mean = ...
        mean(data.Temperature,'omitnan');

end

% Agitator
if ismember("AgitatorRPM",data.Properties.VariableNames)

    params.agitator.meanRPM = ...
        mean(data.AgitatorRPM,'omitnan');

end

fprintf("Parameter identification completed.\n");

end
