function diagnosis = diagnose_fault(residuals, alarms)

diagnosis = struct();

diagnosis.active_fault = "NONE";
diagnosis.confidence = "NONE";
diagnosis.evidence = {};

if alarms.temperature

    diagnosis.active_fault = ...
        "TEMP_SENSOR_DRIFT";

    diagnosis.confidence = "POSSIBLE";

    diagnosis.evidence = ...
        {"Temperature residual above threshold"};

elseif alarms.rpm

    diagnosis.active_fault = ...
        "AGITATOR_MOTOR_MALFUNCTION";

    diagnosis.confidence = "POSSIBLE";

    diagnosis.evidence = ...
        {"RPM residual abnormal"};

elseif alarms.flow

    diagnosis.active_fault = ...
        "FEED_PUMP_MALFUNCTION";

    diagnosis.confidence = "POSSIBLE";

    diagnosis.evidence = ...
        {"Flow residual abnormal"};

elseif alarms.level

    diagnosis.active_fault = ...
        "TANK_LEAKAGE";

    diagnosis.confidence = "POSSIBLE";

    diagnosis.evidence = ...
        {"Mass/level residual abnormal"};

elseif alarms.viscosity

    diagnosis.active_fault = ...
        "VISCOSITY_QUALITY_DEVIATION";

    diagnosis.confidence = "POSSIBLE";

    diagnosis.evidence = ...
        {"Viscosity residual abnormal"};

end

end
