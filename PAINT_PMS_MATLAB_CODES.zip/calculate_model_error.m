function metrics = calculate_model_error(actual,predicted)

err = actual - predicted;

metrics.RMSE = sqrt(mean(err.^2,'omitnan'));

metrics.MAE = mean(abs(err),'omitnan');

valid = actual ~= 0 & ...
        isfinite(actual) & ...
        isfinite(predicted);

if any(valid)

    metrics.MAPE = ...
        mean(abs(err(valid)./actual(valid))) * 100;

else

    metrics.MAPE = NaN;

end

denominator = ...
    sum((actual - mean(actual,'omitnan')).^2,'omitnan');

if denominator > 0

    metrics.R2 = ...
        1 - sum(err.^2,'omitnan')/denominator;

else

    metrics.R2 = NaN;

end

end
