function json = generate_batch_json(batch)

output = struct();

output.batch_id = batch.BatchID;
output.product_grade = batch.ProductGrade;
output.status = batch.Status;
output.elapsed_time_min = batch.ElapsedTime;

json = jsonencode(output);

end
