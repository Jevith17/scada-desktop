function cfg = process_config()

cfg = struct();

% These MUST be populated from company data/datasheets
cfg.tank.volume = NaN;
cfg.tank.diameter = NaN;
cfg.tank.height = NaN;

cfg.material.density = NaN;

cfg.temperature.min = NaN;
cfg.temperature.max = NaN;
cfg.temperature.setpoint = NaN;

cfg.level.min = NaN;
cfg.level.max = NaN;
cfg.level.setpoint = NaN;

cfg.rpm.min = NaN;
cfg.rpm.max = NaN;
cfg.rpm.setpoint = NaN;

cfg.flow.min = NaN;
cfg.flow.max = NaN;
cfg.flow.setpoint = NaN;

cfg.pressure.min = NaN;
cfg.pressure.max = NaN;
cfg.pressure.setpoint = NaN;

cfg.viscosity.min = NaN;
cfg.viscosity.max = NaN;
cfg.viscosity.setpoint = NaN;

end
