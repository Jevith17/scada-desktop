function model = calibrate_pump(data)

model = struct();

required = ["InletFlow","PumpStatus"];

if ~all(ismember(required, ...
        data.Properties.VariableNames))

    model.available = false;
    return;

end

model.available = true;

running = strcmpi(string(data.PumpStatus),"On");

model.meanFlowRunning = ...
    mean(data.InletFlow(running),'omitnan');

end
