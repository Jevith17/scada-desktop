function build_paint_twin()

model = "Paint_Mixing_DigitalTwin";

if bdIsLoaded(model)
    close_system(model,0);
end

new_system(model);
open_system(model);

fprintf("Building Paint Mixing Digital Twin...\n");

% Later:
% add_block(...)
% set_param(...)
% add_line(...)

save_system(model);

fprintf("Simulink model created: %s.slx\n",model);

end
