function model = calibrate_agitator(data)

model = struct();

if ~all(ismember(["AgitatorRPM"], ...
        data.Properties.VariableNames))

    model.available = false;
    return;

end

model.available = true;

model.meanRPM = ...
    mean(data.AgitatorRPM,'omitnan');

model.stdRPM = ...
    std(data.AgitatorRPM,'omitnan');

end
