function [calibrationData, validationData] = ...
    split_calibration_validation(data)

batchIDs = unique(data.BatchID);

rng(1);

batchIDs = batchIDs(randperm(numel(batchIDs)));

nCal = floor(0.70 * numel(batchIDs));

calBatch = batchIDs(1:nCal);
valBatch = batchIDs(nCal+1:end);

calibrationData = ...
    data(ismember(data.BatchID,calBatch),:);

validationData = ...
    data(ismember(data.BatchID,valBatch),:);

fprintf("\nCalibration batches: %d\n", numel(calBatch));
fprintf("Validation batches: %d\n", numel(valBatch));

fprintf("Calibration rows: %d\n", height(calibrationData));
fprintf("Validation rows: %d\n", height(validationData));

end
