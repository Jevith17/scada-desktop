function validation_plots(time,actual,predicted,variable)

figure('Name',variable);

plot(time,actual,'LineWidth',1.5);
hold on;

plot(time,predicted,'--','LineWidth',1.5);

grid on;

xlabel('Time');
ylabel(variable);

legend('Measured','Predicted');

title([variable ' - Validation']);

end
