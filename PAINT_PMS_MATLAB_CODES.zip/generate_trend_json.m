function json = generate_trend_json(history)

output = struct();

output.timestamp = history.Timestamp;

output.tank_level_pct = history.TankLevel;

output.temperature_C = history.Temperature;

output.agitator_rpm = history.AgitatorRPM;

output.feed_flow_kg_min = history.FeedFlow;

output.pressure_bar = history.Pressure;

output.viscosity_cP = history.Viscosity;

output.motor_power_kW = history.MotorPower;

json = jsonencode(output);

end
