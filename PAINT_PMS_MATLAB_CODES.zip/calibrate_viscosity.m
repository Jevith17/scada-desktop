function model = calibrate_viscosity(data)

model = struct();

required = ["Temperature", ...
            "AgitatorRPM", ...
            "Viscosity"];

if ~all(ismember(required, ...
        data.Properties.VariableNames))

    error("Required viscosity variables are missing.");
end

T = data.Temperature;
RPM = data.AgitatorRPM;
Y = data.Viscosity;

valid = isfinite(T) & ...
        isfinite(RPM) & ...
        isfinite(Y);

X = [T(valid), RPM(valid)];

% First-order empirical model
model.coefficients = ...
    regress(Y(valid), ...
    [ones(sum(valid),1), X]);

model.predict = @(temperature,rpm) ...
    [ones(numel(temperature),1), ...
     temperature(:), rpm(:)] * ...
     model.coefficients;

end
