function json = generate_alarm_json(alarms)

output = struct();

output.active = alarms.active;
output.history = alarms.history;

json = jsonencode(output);

end
