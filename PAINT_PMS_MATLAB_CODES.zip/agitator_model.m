function rpm = agitator_model( ...
    rpmSetpoint, motorCondition, gain)

rpm = gain .* rpmSetpoint .* motorCondition;

end
