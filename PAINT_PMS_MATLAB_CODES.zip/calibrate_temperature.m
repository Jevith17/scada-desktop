function model = calibrate_temperature(data)

model = struct();

required = ["Temperature","AgitatorRPM"];

if ~all(ismember(required, ...
        data.Properties.VariableNames))

    model.available = false;
    return;

end

model.available = true;

X = data.AgitatorRPM;
Y = data.Temperature;

valid = isfinite(X) & isfinite(Y);

model.coefficients = ...
    polyfit(X(valid),Y(valid),1);

end
