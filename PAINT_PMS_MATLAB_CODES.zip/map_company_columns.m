function map = map_company_columns()

map.Timestamp      = "Timestamp";
map.BatchID        = "Batch ID";

map.TankLevel      = "Tank Level (%)";

map.InletFlow      = "Inlet Flow (kg/min)";
map.OutletFlow     = "Outlet Flow (kg/min)";

map.Temperature    = "Temperature (°C)";

map.AgitatorRPM    = "Agitator Speed (rpm)";

map.MotorPower     = "Motor Current (A) / Power (kW)";

map.ValvePosition  = "Valve Position (%)";

map.PumpStatus     = "Pump Status (On/Off)";

map.Pressure       = "Pressure (bar, if available)";

map.Viscosity      = "Viscosity (cP)";

map.pH             = "pH (if available)";

map.BatchSize      = "Batch Size (kg or L)";

map.MixingTime     = "Mixing Duration (min)";

map.ProductGrade   = "Product / Grade";

map.FinalQC        = "Final QC Result (Pass/Fail)";

fprintf("Company column mapping loaded.\n");

end
