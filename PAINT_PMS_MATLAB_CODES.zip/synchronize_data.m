function dataSync = synchronize_data(data, sampleTime)

TT = table2timetable(data, ...
    'RowTimes', data.Timestamp);

TT = sortrows(TT);

% Synchronize to selected sample interval
newTime = (TT.Time(1):sampleTime:TT.Time(end))';

dataSync = retime(TT, newTime, 'linear');

dataSync = timetable2table(dataSync, ...
    'ConvertRowTimes', true);

dataSync.Properties.VariableNames{1} = 'Timestamp';

fprintf("Data synchronized to %s sample interval.\n", ...
    char(sampleTime));

end
