Source document code files extracted/organized:

agitator_model.m
build_paint_twin.m
calculate_model_error.m
calibrate_agitator.m
calibrate_flow.m
calibrate_pump.m
calibrate_temperature.m
calibrate_valve.m
calibrate_viscosity.m
clean_process_data.m
detect_faults.m
detect_outliers.m
diagnose_fault.m
energy_balance.m
fault_injection.m
generate_alarm_json.m
generate_batch_json.m
generate_diagnosis_json.m
generate_live_json.m
generate_trend_json.m
identify_parameters.m
load_company_excel.m
main.m
map_company_columns.m
paint_dynamic_model.m
process_config.m
pump_model.m
quality_deviation.m
residual_generator.m
segment_batches.m
sensor_model.m
split_calibration_validation.m
synchronize_data.m
tank_mass_balance.m
validate_model.m
validation_plots.m
valve_model.m
viscosity_model.m

The source document also lists these files in the folder structure but does not provide their implementation bodies: startup.m, equipment_config.m, api_config.m, material_addition_model.m, quality_model.m, validation_report.m.
